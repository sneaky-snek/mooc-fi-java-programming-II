package FlightControl.ui;


public interface UserInterface {
    void start();

    void airplaneAdd();

    void flightAdd();

    void listAirplanes();

    void listFlights();

    void listPlane();
}
